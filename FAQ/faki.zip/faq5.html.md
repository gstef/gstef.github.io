```
author: Grzesiek Stefanek
title: Czy moje ukulele jest ze sklejki czy z drewna?
tags: ['faq','faq-kupno']
date: 2017-01-18 22:50:58+00:00
description: Jeśli sprzedawca nie zaznaczył wyraźnie, że z litego drewna, to na pewno ze sklejki
sekcja: 1
numer: 5
```
Jeśli ukulele jest wykonane z litego drewna, to na 99% producent to podkreśli w opisie pisząc LITE drewno / solid wood. Jeśli pisze po prostu o drewnie, ale także konkretnie o mahoniu czy innym gatunku, to niemal na pewno chodzi o sklejkę mahoniową czy inną. Jest to niestety częsty i trochę nieuczciwy marketing. Nie ma znaczenia, poza estetycznym, czy sklejka jest np. „mahoniowa”, bo i tak nie wiemy, z czego się składa w środku. Już nawet pomijając fakt, że w dużej części składa się po prostu z kleju.
