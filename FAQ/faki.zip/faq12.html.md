```
author: Grzesiek Stefanek
title: Która struna jest która?
tags: ['faq','faq-nauka']
date: 2017-01-18 22:50:58+00:00
description: Od góry: G, C, E, A
sekcja: 2
numer: 12
```
Patrząc od góry, gdy trzymasz ukulele w pozycji tak, jak do gry, widzisz struny kolejno G, C, E i A. Numeracja natomiast jest odwrotna i struną pierwszą jest najniżej położona, czyli A. Niektórzy producenci strun, np. popularna Aquila, stosują też własne oznaczenia kolorami.

Najważniejsze, by zapamiętać G, C, E i A – nazwy dźwięków będą potrzebne zarówno do strojenia, jak i do gry.
