```
author: Grzesiek Stefanek
title: Skąd mam wziąć „bicie” do piosenki, którą chcę zagrać?
tags: ['faq','faq-nauka']
date: 2017-01-18 22:50:58+00:00
description: Niestety, w zasadzie tylko "na słuch" lub z nagrania wideo.
sekcja: 2
numer: 14
```
W przeciwieństwie do zapisu akordów, rzadko w śpiewnikach znajdziemy opis pracy prawej ręki. Choćby z tego względu, że nie ma spójnej i prostej konwencji zapisu, choć znajdziemy różne wariacje na temat „góra-dół-góra”, strzałek, innych opisów, lub po prostu zapis rytmu wzięty z pełnej notacji muzycznej, czyli z nut. Niestety, śpiewnik to wskazówka, a nie pełnoprawny zapis muzyki.

Najczęściej więc będziemy zdani na swój słuch i nagrania. W rozgryzaniu bicia pomagać może próba rytmicznego stukania czy klaskania, a następnie przeniesienie tego rytmu na ukulele. Gdy własne możliwości was zawiodą, zawsze można zapytać na grupie, może jakaś życzliwa dusza nagra dla was próbkę?
