```
author: Grzesiek Stefanek
title: Mam tanie ukulele, kiedy warto wymienić je na lepsze?
tags: ['faq','faq-kupno']
date: 2017-01-18 22:50:58+00:00
description: Jeśli się zastanawiasz, czy warto, to zapewne jeszcze nie warto.
sekcja: 1
numer: 8
```
Pewnie, że dobrze czasem zrobić sobie prezent. Ale jeśli twoje ukulele poprawnie stroi, to zastanów się dwa razy przed zakupem nowego. UAS (Ukulele Acquisition Syndrome) to trochę autoironiczne określenie, ale problem jest rzeczywisty – wielu ukistów, zamiast cieszyć się grą, poświęca czas na myślenie o tym, czego by tu nie zagrali, gdyby tylko już mieli to wymarzone, lepsze ukulele. Nie tędy droga.

Wymiana poprawnie grającego, ale taniego ukulele na trochę tylko droższe, np. przejście z jednego z polecanych przez nas modeli za około 250zł na bardziej markowy instrument za 400-500zł, tak naprawdę niewiele wniesie. Sens ma dopiero przejście o klasę wyżej, czyli już na ukulele z litego drewna. Do tego czasu lepiej cieszyć się grą na tym, co masz.
