```
author: Grzesiek Stefanek
title: Czy warto kupić ukulele z plastiku?
tags: ['faq','faq-kupno']
date: 2017-01-18 22:50:58+00:00
description: Raczej nie warto, chyba że przynajmniej płyta przednia jest z drewna lub laminatu
sekcja: 1
numer: 3
```
Plastikowe ukulele to szeroki temat, ale jak dotąd brzmienie większości z nich pozostawia wiele do życzenia, nawet w porównaniu z tanimi sklejkami. Zaletą za to jest powtarzalność produkcji, więc plastikowe ukulele jak np. Korala PUC czy Makala Waterman może być dobrym wyborem, jeśli naprawdę nie możemy przeznaczyć nawet tych 200 zł na przyzwoitą sklejkę.

Dobrym wyborem są natomiast ukulele łączące zalety plastiku z wierzchnią płytą z drewna, np. tańsze Mahilele czy droższe Flea.
