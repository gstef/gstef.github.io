```
author: Grzesiek Stefanek
title: Czy mogę na ukulele grać kostką?
tags: ['faq','faq-nauka']
date: 2017-01-18 22:50:58+00:00
description: Tak, ale polecamy najpierw nauczyć się gry palcami.
sekcja: 2
numer: 13
```
Tradycyjnie na ukulele gra się palcami lub stosuje się specjalne kostki z filcu, uzyskując bardzo miękkie, kojarzące się z muzyką hawajską brzmienie. Nie ma jednak powodu, by się ograniczać, i spokojnie można eksperymentować z twardymi kostkami gitarowymi. Będzie to miało tylko niekorzystny wpływ na trwałość strun, łatwo też zarysować pudło.

Warto jednak nie zaczynać od tego, tylko opanować tradycyjną technikę palcami, kostkę traktując jako ciekawe rozszerzenie możliwości. Podstawy są ważniejsze od bajerów.
