```
author: Grzesiek Stefanek
title: Czy możecie wskazać jakieś modele dobre na początek?
tags: ['faq','faq-kupno']
date: 2017-01-18 22:50:58+00:00
description: Zainteresuj się poniższymi propozycjami, jeśli potrzebujesz koniecznie porady  tego typu. Ale przeczytaj również, co napisaliśmy w pytaniu „Ile wydać na pierwsze ukulele”, i dlaczego kierowanie się rekomendacjami nie gwarantuje udanego zakupu.
sekcja: 1
numer: 7
```
**Mahilele 3.0**
Udane połączenie plastiku i sklejki, daje przyjemne brzmienie przy bardzo dobrej powtarzalności produkcji. Prawdopodobnie najczęściej ostatnio polecane ukulele dla początkujących.

**Makala Dolphin / Shark** –klasyczny wybór, prawie każdy ukulelista ma „delfinka” w kolekcji. Bardzo tanie, raczej sprawdzone, ale często wymaga drobnych poprawek w regulacji. Wybierz, jeśli koniecznie chcesz się zmieścić poniżej 200 zł. Obiektywnie brzmi słabo, ale jest to słabość w pewnym sensie kultowa.

**Flight NUS 310** – porządnie wykonany sopran, marki stosunkowo nowej na polskim rynku. Typowa sklejka z polecanej przez nas półki cenowej.

**EverPlay 2130 / 2150** – firma o bardzo złej sławie z rynku gitarowego, ale w ukulele akurat niezasłużonej. Typowa, nieźle wykonana sklejka, choć zdarzają się wpadkowe egzemplarze.

**Hora S1175** – jeżeli naprawdę koniecznie chcecie zakupić ukulele z litego drewna, choć raczej tego nie polecamy. Posiada klucze kołkowe, które dla początkujących mogą być bardzo niewygodne. Rzadkością na tej półce cenowej jest produkcja w Europie.

**Mellow UKC-HM / UKS-ZB** – kolejna często polecana sklejka, która nie powinna rozczarować.
