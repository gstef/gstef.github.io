```
author: Grzesiek Stefanek
title: Czy warto kupić ukulele z litego drewna?
tags: ['faq','faq-kupno']
date: 2017-01-18 22:50:58+00:00
description: Na początek nie. Później jak najbardziej tak, ale nie spiesz się z tym, i przygotuj się na większy wydatek.
sekcja: 1
numer: 6
```
Lite drewno to zdecydowana poprawa brzmienia, co jednak nie wynika tylko z lepszych właściwości samego materiału, jak po prostu z faktu że są to instrumenty znacznie lepiej wykonane od budżetowych sklejek. Lite drewno to również jednak nieznane sklejce problemy z konserwacją czy utrzymaniem prawidłowej wilgotności. Raczej nie będzie to ukulele do gry przy ognisku, dlatego zawsze warto mieć też tani instrument z laminatu w kolekcji.

Najtańsze ukulele z litego drewna nie są dobrą inwestycją. Cudów nie ma, to jest drogi materiał, więc oszczędności producenta muszą ujawnić się w jakości wykonania samego instrumentu.

Krótko mówiąc – kup wtedy, kiedy już wiesz, co robisz i czego potrzebujesz.
