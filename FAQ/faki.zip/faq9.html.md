```
author: Grzesiek Stefanek
title: Czy nauka gry na ukulele jest łatwa?
tags: ['faq','faq-nauka']
date: 2017-01-18 22:50:58+00:00
description: Początki są łatwiejsze, niż dla wielu innych instrumentów. Później jest już tak, jak zwykle.
sekcja: 2
numer: 9
```
To jest pełnoprawny, polifoniczny instrument muzyczny. Nie można więc powiedzieć, że opanowanie go jest zadaniem trywialnym, ponieważ muzyka taka nie jest. A uczyć się grać można i należy przez całe życie.

Dlaczego zatem jednak mówimy, że na ukulele jest to łatwe? Dlatego, że w przeciwieństwie do wielu innych instrumentów bardzo szybko przychodzą pierwsze efekty, przyjemne, lub przynajmniej bezbolesne dla muzyka i otoczenia. Tak jak np. adept gry na skrzypcach będzie miesiącami i latami ćwiczył, zanim zagra coś zdatnego do posłuchania, tak podstawy na ukulele są do opanowania w dosłownie kwadrans, po którym można już akompaniować sobie do prostych piosenek. Ale oczywiście nie znaczy to, że zaawansowane umiejętności przyjdą równie szybko i prosto.

Ukulele jest również niewątpliwie przystępniejsze (na początku) od gitary, ze względu na mniejszą liczbę strun i ich mniejszy naciąg, co znacznie ułatwia naukę czystego wydobywania dźwięków i akordów początkującym.
