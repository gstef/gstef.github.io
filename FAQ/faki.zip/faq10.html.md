```
author: Grzesiek Stefanek
title: Jaki strój ukulele wybrać?
tags: ['faq','faq-nauka']
date: 2017-01-18 22:50:58+00:00
description: Najbardziej popularny – C6 z wysokim G, czyli kolejno dźwięki G4, C4, E4 i A4
sekcja: 2
numer: 10
```
Alternatywne stroje ukulele, czyli przede wszystkim *niskie G*, *kanadyjskie D6*, strój barytonowy oraz wiele innych, rzadziej spotykanych wariacji, to ciekawe urozmaicenia. Ale nie są dobrym wyborem na początek i na razie nie zawracajcie sobie nimi głowy.
