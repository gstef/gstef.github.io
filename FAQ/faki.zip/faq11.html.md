```
author: Grzesiek Stefanek
title: Jak najlepiej nastroić ukulele?
tags: ['faq','faq-nauka']
date: 2017-01-18 22:50:58+00:00
description: Na początku zaopatrz się w stroik, lub w aplikację na telefon. Jeśli masz wątpliwości, jak jej użyć, przeczytaj o tym w naszym poradniku „Pierwsze kroki z ukulele".
sekcja: 2
numer: 11
```
Uważamy że strojenie z pomocą stroika lub appki jest najlepszym sposobem dla początkujących. Oczywiście należy się docelowo nauczyć stroić „na słuch”, ale głównie dlatego, że nie wypada tego nie umieć. Nie ma jednak potrzeby dokładać sobie na początek jeszcze jednej umiejętności do opanowania, ważniejsze jest, by od początku grać na dobrze nastrojonym instrumencie.
