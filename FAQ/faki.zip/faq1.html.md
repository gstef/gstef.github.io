```
author: Grzesiek Stefanek
title: Jaki rozmiar ukulele wybrać na początek?
tags: ['faq','faq-kupno']
date: 2017-01-18 22:50:58+00:00
description: Często zadawane pytania o Ukulele
short: Na pierwsze ukulele polecamy rozmiar sopran
numer: 1
sekcja: 1
```

Tak naprawdę to taki,  jaki ci się najbardziej spodoba, i jeśli traficie na ukulele które do was szczególnie przemawia „kup mnie”, to zignorujcie wszystko poniższe. Polecamy jednak zwykle sopran dlatego, że:

- Jest to najbardziej kanonicznie brzmiące ukulele
- Jest najpopularniejszy, więc wybór w sklepie będzie największy
- Jest najtańszy – za daną kwotę kupisz lepszy sopran niż inny rozmiar
- Zalety większych rozmiarów ujawniają się dopiero przy bardziej zaawansowanej grze, czyli nie są w zasadzie potrzebne początkującym
- Jeśli nauczysz się grać na sopranie, umiesz też grać na większych ukulele. W drugą stronę wymaga to przyzwyczajenia do mniejszych rozmiarów gryfu
- Gwarantujemy, że to i tak nie będzie wasze ostatnie ukulele, w końcu i tak kupicie droższe i lepsze.  Właśnie wtedy, kiedy większe możliwości większego ukulele zaczną wam być potrzebne.  Wasz pierwszy sopran pozostanie jako instrument wyjazdowo-imprezowy.  Jest to logiczna kolejność zakupów.

Nie jest prawdą, że niektórzy mają zbyt duże dłonie do gry na sopranie. Szybko idzie się przyzwyczaić i jeśli nie masz łapy jak łycha od koparki, dasz sobie radę.
