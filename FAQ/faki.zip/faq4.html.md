```
author: Grzesiek Stefanek
title: Czym się różni sklejka od drewna?
tags: ['faq','faq-kupno']
date: 2017-01-18 22:50:58+00:00
description: Tym, czym mięso od parówki z Biedronki, ale i parówki mają swoje zalety
sekcja: 1
numer: 4
```
Sklejka, czyli laminat, to kompozyt z warstw drewna i kleju. Jest oczywiście tańszy od litego drewna, ma również inne zalety – jest trwały, łatwo się formuje, nie odkształca się i raczej nie pęka dopóki na nim nie usiądziesz. Ma jednak gorsze właściwości akustyczne.
