```
author: Grzesiek Stefanek
title: Ile wydać na pierwsze ukulele?
tags: ['faq','faq-kupno']
date: 2017-01-18 22:50:58+00:00
description: 200-300 zł to optymalna kwota na pierwsze ukulele. Należy wystrzegać się czegokolwiek tańszego niż 150 zł, a wszystko powyżej 350zł będzie miłe, ale raczej na początek niepotrzebne
sekcja: 1
numer: 2
```
Podstawowym zadaniem pierwszego ukulele nie jest to, żeby było szczególnie dobre. Chodzi raczej o to, żeby nie było złe, czyli nie miało wad uniemożliwiających lub bardzo utrudniających grę – niestrojenia na progach, zwichrowanego gryfu, luzujących się kluczy itp. Brzmienie to na razie kwestia drugorzędna.

Przedział 200-300zł to cena, w której ukulele ze sklejki przechodzi już podstawową kontrolę jakości. Wady zupełnie dyskwalifikujące instrument zdarzają się rzadko. Drobne problemy z intonacją czy akcją strun wciąż występują, ale nie uniemożliwiają gry, a i dadzą się przy odrobinie wiedzy samodzielnie usunąć. Jest to więc w miarę bezpieczny zakup dla początkującego.  Poniżej tej kwoty odsetek nieudanych instrumentów rośnie bardzo wyraźnie i po prostu nie warto ryzykować, chyba że mamy już wiedzę i możliwość by wybrać konkretny, udany egzemplarz.

Dokładając nieco więcej pieniędzy natomiast nie zyskujemy wiele, przynajmniej dopóki nie dotrzemy do poziomu cenowego dla podstawowych ukulele z litego drewna, czyli od 500-700zł w górę. Różnica między sklejką za 250 a 400zł będzie w estetyce, czasem w prestiżu marki, ale raczej niewielka w samym brzmieniu.
